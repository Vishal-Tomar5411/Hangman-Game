# Hangman-game
 Developed an interactive Hangman game using HTML, CSS, and JavaScript. Implemented responsive design for optimal user experience across devices. The game features dynamic word generation, real-time letter input validation, and visually appealing animations to enhance player engagement
